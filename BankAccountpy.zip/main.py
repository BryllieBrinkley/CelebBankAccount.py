class BankAccount():
  def __init__(self, full_name, account_num, routing_num, balance):
    self.full_name = full_name
    self.account_num = account_num
    self.routing_num = routing_num
    self.balance = balance
    
  def deposit(self, amount):
    self.balance = self.balance + amount
    print(f"Amount Deposited: {amount}")

  def withdraw(self, amount):
    print(f"here")
    if self.balance <= amount:
      print("Innsuficient funds. You will be charged an overdraft fee of $10.")
      self.balance = self.balance - 10
    else:
      self.balance = self.balance - amount
      print(f"Amount Withdrawn: {amount} from {self.balance} with an Overdraft fee of $10.")
      
  def get_balance(self):
    print(f"Hello, your current total account balance is: {self.balance} . Have a good day!")
  

  def add_interest(self):
    interest = self.balance *  0.00083
    self.balance = self.balance + interest
    print(self.balance)

  def print_reciept(self):
    print(f"{self.full_name} \n Account No. {self.account_num} \n Routing No. {self.routing_num} \n Balance: {self.balance}")
    
    
    
Jibryll = BankAccount("bryll", 87645321, 132457689, 86)

Jibryll.deposit(10)
Jibryll.withdraw(40)
Jibryll.get_balance()
Jibryll.add_interest()
Jibryll.print_reciept()

Beyonce = BankAccount("Beyonce K.", 660781, 668321865, 500567890)

Beyonce.deposit(0)
Beyonce.withdraw(1400)
Beyonce.get_balance()
Beyonce.add_interest()
Beyonce.print_reciept()

Jennifer = BankAccount("Jennifer L.", 997365, 98015679, 221561782)

Jennifer.deposit(50000)
Jennifer.withdraw(40)
Jennifer.get_balance()
Jennifer.add_interest()
Jennifer.print_reciept()